package com.example.appmotivacao

import kotlin.random.Random

class frase (val descricao: String, val IdCategoria: Int)

class Frases {

    private val AllInclusive = 1
    private val Emoji = 2
    private val Sunny = 3

    val ListaDeFrases = listOf<frase>(
        frase("Não sabendo que era impossível, foi lá e fez.", Emoji),
        frase("Você não é derrotado quando perde, mas sim quando desiste!", Emoji),
        frase("A melhor maneira de prever o futuro é inventá-lo.", Sunny),
        frase("Você perde todas as chances que não aproveita.", Sunny)
    )

    fun ObterFrase(valor: Int): String {

        val ListaFiltrada = ListaDeFrases.filter { it.IdCategoria == valor || valor == AllInclusive}
        return ListaFiltrada[Random.nextInt(ListaFiltrada.size)].descricao
    }
}