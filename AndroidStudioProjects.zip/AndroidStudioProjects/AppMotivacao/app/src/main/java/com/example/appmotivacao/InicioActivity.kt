package com.example.appmotivacao

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import com.example.appmotivacao.databinding.ActivityInicioBinding


class InicioActivity : AppCompatActivity(), View.OnClickListener {

    private lateinit var binding: ActivityInicioBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityInicioBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.buttonSalvar.setOnClickListener(this)

        supportActionBar?.hide()

        VerificarUsuario()
    }

    override fun onClick(v: View) {
        if (v.id == R.id.button_salvar) {
            FuncaoSalvar()
        }
    }

    private fun FuncaoSalvar() {
        val nome = binding.edittextNome.text.toString()

        if (nome != "") {
            PreferenciasSeguras(this).GuardaString("NomeUsuario", nome)
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        } else {
            Toast.makeText(this, R.string.msg_validacao_nome, Toast.LENGTH_SHORT).show()
        }
    }

    private fun VerificarUsuario(){
        val nome = PreferenciasSeguras(this).ObtemString("NomeUsuario")
        if (nome != "") {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }
}