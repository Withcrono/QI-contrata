package com.example.appmotivacao

import android.content.Context
import android.content.SharedPreferences

class PreferenciasSeguras(context: Context) {

    private val security: SharedPreferences =
        context.getSharedPreferences("Motivacao", Context.MODE_PRIVATE)

    fun GuardaString(chave: String, valor: String) {
        security.edit().putString(chave, valor).apply()
    }

    fun ObtemString(chave: String): String {
        return security.getString(chave, "") ?: ""
    }
}