package com.example.appmotivacao

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import androidx.core.content.ContextCompat
import com.example.appmotivacao.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity(), View.OnClickListener {

    private lateinit var binding: ActivityMainBinding
    private var IdCategoria = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //escondendo a barra de navegação
        supportActionBar?.hide()

        FuncaoSaudaUsuario()
        FuncaoTrataIcones(R.id.image_all_inclusive)
        FuncaoProximaFrase()

        //Eventos
        binding.buttonNovaFrase.setOnClickListener(this)
        binding.imageAllInclusive.setOnClickListener(this)
        binding.imageEmoji.setOnClickListener(this)
        binding.imageSunny.setOnClickListener(this)
    }

    override fun onClick(view: View) {
        if (view.id == R.id.button_nova_frase) {
            FuncaoProximaFrase ()
        } else if (view.id in listOf(R.id.image_all_inclusive, R.id.image_emoji, R.id.image_sunny)) {
            FuncaoTrataIcones(view.id)
        }
    }

    private fun FuncaoProximaFrase () {
        binding.textviewFrase.text = Frases().ObterFrase(IdCategoria)
    }
    private fun FuncaoTrataIcones (icone: Int) {

        binding.imageEmoji.setColorFilter(ContextCompat.getColor(this, R.color.cinza_escuro))
        binding.imageSunny.setColorFilter(ContextCompat.getColor(this, R.color.cinza_escuro))
        binding.imageAllInclusive.setColorFilter(ContextCompat.getColor(this, R.color.cinza_escuro))

        when (icone) {
            R.id.image_all_inclusive -> {
                binding.imageAllInclusive.setColorFilter(ContextCompat.getColor(this, R.color.white))
                IdCategoria = 1
                FuncaoProximaFrase ()
            }
            R.id.image_emoji -> {
                binding.imageEmoji.setColorFilter(ContextCompat.getColor(this, R.color.white))
                IdCategoria = 2
                FuncaoProximaFrase ()
            }
            R.id.image_sunny -> {
                binding.imageSunny.setColorFilter(ContextCompat.getColor(this, R.color.white))
                IdCategoria = 3
                FuncaoProximaFrase ()
            }
        }
    }

    private fun FuncaoSaudaUsuario() {
        val nome = PreferenciasSeguras(this).ObtemString("NomeUsuario")
        binding.textviewSaudacao.text = "Olá, $nome!"
    }
}